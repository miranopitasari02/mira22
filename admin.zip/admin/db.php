<?php
$con = mysqli_connect("localhost","root","","db_hotel_mirans12") or die(mysql_error());

?>